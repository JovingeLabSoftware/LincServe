library(testthat)
library(slinky)

test_check("slinky")